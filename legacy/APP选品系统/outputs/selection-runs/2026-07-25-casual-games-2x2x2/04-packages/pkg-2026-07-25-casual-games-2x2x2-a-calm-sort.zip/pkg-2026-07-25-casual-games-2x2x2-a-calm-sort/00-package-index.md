# Calm Sort（舒缓分类） — Workbench Package

- Package ID: `pkg-2026-07-25-casual-games-2x2x2-a-calm-sort`
- Candidate ID: `2026-07-25-casual-games-2x2x2-a-calm-sort`
- Source engine: `competitor_validated`
- Route score: 79
- Route rank: 2
- Route methodology: `route-a-competitor-v1.1`
- Data completeness: 82%
- Status: `READY_FOR_BENCH`

## Read order

1. `01-product-brief.md`
2. `02-evidence-and-references.md`
3. `03-brand-ui-direction.md`
4. `05-acceptance-criteria.md`
5. `06-growth-plan.md`
6. `07-analytics-and-stop.md`
7. `04-build-master-prompt.md`

Do not start implementation when any required file or acceptance section is missing.
