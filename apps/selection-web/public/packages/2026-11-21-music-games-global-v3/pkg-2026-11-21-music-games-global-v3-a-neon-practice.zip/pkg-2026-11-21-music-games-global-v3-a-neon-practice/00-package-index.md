# NeonPractice（霓虹练习室） — Workbench Package

- Package ID: `pkg-2026-11-21-music-games-global-v3-a-neon-practice`
- Candidate ID: `2026-11-21-music-games-global-v3-a-neon-practice`
- Source engine: `competitor_validated`
- Route score: 87
- Route rank: 3
- Route methodology: `route-a-competitor-v1.1`
- Data completeness: 80%
- Status: `READY_FOR_BENCH`

## Read order

1. `01-product-brief.md`
2. `02-evidence-and-references.md`
3. `03-brand-ui-direction.md`
4. `05-acceptance-criteria.md`
5. `06-growth-plan.md`
6. `07-analytics-and-stop.md`
7. `04-build-master-prompt.md`

Do not start implementation when any required file or acceptance section is missing.
